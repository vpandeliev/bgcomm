TODO
====

* Once Django 1.2 ships with signed cookies (hopefully), replace
  contrib.sessions dependency with a signed cookie.
